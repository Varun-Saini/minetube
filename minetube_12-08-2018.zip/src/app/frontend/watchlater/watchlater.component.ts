import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-watchlater',
  templateUrl: './watchlater.component.html',
  styleUrls: ['./watchlater.component.css']
})
export class WatchlaterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
